// Optional alternate entry
require('./server');
